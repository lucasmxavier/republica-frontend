import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RepublicaListComponent } from './republica-list/republica-list.component';
import { RepublicaFormComponent } from './republica-form/republica-form.component';
import { RepublicadisponivelListComponent } from './republicadisponivel-list/republicadisponivel-list.component';
import { RepublicaReceitaDespesaFormComponent } from './republica-receita-despesa-form/republica-receita-despesa-form.component';
import { RepublicaReceitaDespesaListComponent } from './republica-receita-despesa-list/republica-receita-despesa-list.component';
import { MoradorFormComponent } from './morador-form/morador-form.component';
import { RepublicaMoradoresComponent } from './republica-moradores/republica-moradores.component';
import { RepublicaFinancasComponent } from './republica-financas/republica-financas.component';
import { MoradorFinancasComponent } from './morador-financas/morador-financas.component';
import { MoradorListComponent } from './morador-list/morador-list.component';
import { FeedbackFormComponent } from './feedback-form/feedback-form.component';
import { FeedbackListComponent } from './feedback-list/feedback-list.component';

const routes: Routes = [
  { path: 'republicas', component: RepublicaListComponent },
  { path: 'addrepublica', component: RepublicaFormComponent },
  { path: 'republicas/disponiveis', component: RepublicadisponivelListComponent },
  { path: 'republicas/addreceitasdespesas', component: RepublicaReceitaDespesaFormComponent },
  { path: 'republicas/receitasdespesas', component: RepublicaReceitaDespesaListComponent },
  { path: 'republica/financas', component: RepublicaFinancasComponent },
  { path: 'morador/financas', component: MoradorFinancasComponent },
  { path: 'addmorador', component: MoradorFormComponent },
  { path: 'morador', component: MoradorFormComponent },
  { path: 'republicas/moradores', component: RepublicaMoradoresComponent },
  { path: 'morador/list', component: MoradorListComponent },
  { path: 'feedback', component: FeedbackListComponent },
  { path: 'addfeedback', component: FeedbackFormComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
