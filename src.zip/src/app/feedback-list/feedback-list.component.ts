import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FeedbackService } from '../services/feedback.service';
import { Feedback } from '../models/feedback';

@Component({
  selector: 'app-feedback-list',
  templateUrl: './feedback-list.component.html',
  styleUrls: ['./feedback-list.component.css']
})
export class FeedbackListComponent implements OnInit {

  feedbacks: Feedback[];
  displayedColumns: string[] = ['id', 'morador', 'republica', 'status',
   'tipo', 'descricao','dataFeedback',  'dataSolucao', 'acoes'];

  constructor(private route: ActivatedRoute, private router: Router,
    private feedbackService: FeedbackService) { }

  ngOnInit() {
  }

  onUpdate(feedback: Feedback) {
    this.feedbackService.setFeedback(feedback);
    this.router.navigate(['/addfeedback']);
  }

  onDelete(id: number) {
    /*this.feedbackService.delete(id).subscribe(result => {
      alert('Feedback deletado!');
      this.ngOnInit();
    });*/
  }

  onCreate() {
    let feedback = new Feedback();
    this.feedbackService.setFeedback(feedback);
    this.router.navigate(['/addfeedback']);
  }
}

