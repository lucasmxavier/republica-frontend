import { Component, OnInit } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { MoradorService } from '../services/morador.service';
import { MatDialog } from '@angular/material/dialog';
import { Morador } from '../models/morador';
import { SolicitacaoService } from '../services/solicitacao.service';
import { Solicitacao } from '../models/solicitacao';
import { NotificacaoListDialogComponent } from '../notification-list-dialog/notificacao-list-dialog.component';

@Component({
  selector: 'app-main-nav',
  templateUrl: './main-nav.component.html',
  styleUrls: ['./main-nav.component.css']
})
export class MainNavComponent implements OnInit {

  morador = new Morador();
  moradores: Morador[] = [];
  solicitacoes: Solicitacao[] = [];

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

  constructor(private breakpointObserver: BreakpointObserver,
    private moradorService: MoradorService,
    private solicitacaoService: SolicitacaoService,
    private dialog: MatDialog) { }

  onChange(value: Morador) {
    this.solicitacaoService.setMorador(value);
    this.morador = this.solicitacaoService.getMorador();

    this.ngOnInit();
  }

  ngOnInit() {

    this.atualizarListaSolicitacaoes();

    this.moradorService.findAll()
      .subscribe(data => {
        this.moradores = data;
      });
  }

  visualizarNotificacoes(solicitacoes: Solicitacao[]): void {
    const dialogRef = this.dialog.open(NotificacaoListDialogComponent, {
      width: '600px',
      data: solicitacoes
    });

    dialogRef.afterClosed().subscribe(result => {
      this.atualizarListaSolicitacaoes();
    });
  }

  atualizarListaSolicitacaoes() {
    this.solicitacaoService.findAll(this.morador.id)
      .subscribe(data => {
        this.solicitacoes = data;
      });
  }
}

