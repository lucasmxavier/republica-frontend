import { MoradorReceitaDespesa } from './morador-receita-despesa';

describe('MoradorReceitaDespesa', () => {
  it('should create an instance', () => {
    expect(new MoradorReceitaDespesa()).toBeTruthy();
  });
});
