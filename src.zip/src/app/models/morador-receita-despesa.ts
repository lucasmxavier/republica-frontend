export class MoradorReceitaDespesa {
    idMorador: number;
    idRepublica: number;
    valor: number;
    valorPago: number;
}
