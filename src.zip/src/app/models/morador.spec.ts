import { Morador } from './morador';

describe('Morador', () => {
  it('should create an instance', () => {
    expect(new Morador()).toBeTruthy();
  });
});
