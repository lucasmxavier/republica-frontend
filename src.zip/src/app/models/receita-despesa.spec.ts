import { ReceitaDespesa } from './receita-despesa';

describe('ReceitaDespesa', () => {
  it('should create an instance', () => {
    expect(new ReceitaDespesa()).toBeTruthy();
  });
});
