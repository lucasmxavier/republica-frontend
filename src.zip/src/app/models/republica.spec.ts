import { Republica } from './republica';

describe('Republica', () => {
  it('should create an instance', () => {
    expect(new Republica()).toBeTruthy();
  });
});
