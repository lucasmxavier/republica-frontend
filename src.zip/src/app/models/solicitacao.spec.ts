import { Solicitacao } from './solicitacao';

describe('Solicitacao', () => {
  it('should create an instance', () => {
    expect(new Solicitacao()).toBeTruthy();
  });
});
