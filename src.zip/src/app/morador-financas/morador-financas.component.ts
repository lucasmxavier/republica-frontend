import { Component, OnInit } from '@angular/core';
import { ReceitaDespesa } from '../models/receita-despesa';
import { ActivatedRoute, Router } from '@angular/router';
import { ReceitadespesaService } from '../services/receitadespesa.service';

@Component({
  selector: 'app-morador-financias',
  templateUrl: './morador-financas.component.html',
  styleUrls: ['./morador-financas.component.css']
})
export class MoradorFinancasComponent implements OnInit {

  receitaDespesa: ReceitaDespesa[];
  
  displayedColumns: string[] = ['tipo', 'descricao', 'valor', 'periodo', 'dataLancamento', 'dataVencimentoRecebimento'];

  constructor(private route: ActivatedRoute, private router: Router, private receitadespesaService: ReceitadespesaService) { }

  ngOnInit() {
    this.receitadespesaService.findAll().subscribe(data =>{
      this.receitaDespesa = data;
    });
  }

}
