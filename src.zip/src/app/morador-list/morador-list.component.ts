import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-morador-list',
  templateUrl: './morador-list.component.html',
  styleUrls: ['./morador-list.component.css']
})
export class MoradorListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
