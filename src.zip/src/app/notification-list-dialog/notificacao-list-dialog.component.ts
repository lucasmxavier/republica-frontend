import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Solicitacao } from '../models/solicitacao';
import { RepublicaService } from '../services/republica.service';
import { SolicitacaoService } from '../services/solicitacao.service';
import { Republica } from '../models/republica';

@Component({
  selector: 'app-notificacao-list-dialog',
  templateUrl: './notificacao-list-dialog.component.html',
  styleUrls: ['./notificacao-list-dialog.component.css']
})

export class NotificacaoListDialogComponent {
  private republica: Republica;

  constructor(
    public dialogRef: MatDialogRef<NotificacaoListDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Solicitacao[],
    private republicaService: RepublicaService,
    private solicitacaoService: SolicitacaoService) { }


  public aceitarMorador(solicitacao: Solicitacao) {
    this.republicaService.setRepublica(solicitacao.republica);
    this.republicaService.addMorador(solicitacao.solicitante)
      .subscribe(response => {
        console.log(response);
        if (response) {
          this.solicitacaoService.delete(solicitacao.id)
            .subscribe(result => {
              var id = this.data.indexOf(solicitacao);
              this.data.splice(id, 1);
            });
          alert("Morador adicionado com sucesso!");
        } else {
          alert("Morador nao pode ser adicionado!");
        }
      });
  }

  public recusarMorador(solicitacao: Solicitacao) {
    this.solicitacaoService.delete(solicitacao.id)
      .subscribe(result => {
        var id = this.data.indexOf(solicitacao);
        this.data.splice(id, 1);
        alert('Solicitação excluída com sucesso!');
      });
  }

}
