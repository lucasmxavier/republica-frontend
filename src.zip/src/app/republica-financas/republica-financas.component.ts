import { Component, OnInit } from '@angular/core';
import { ReceitaDespesa } from '../models/receita-despesa';
import { ReceitadespesaService } from '../services/receitadespesa.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-republica-financias',
  templateUrl: './republica-financas.component.html',
  styleUrls: ['./republica-financas.component.css']
})
export class RepublicaFinancasComponent implements OnInit {

  receitaDespesas: ReceitaDespesa[];
  despesaTotal: number;
  receitaTotal: number;

  displayedColumns: string[] = ['tipo', 'descricao', 'valor', 'periodo', 'dataLancamento', 'dataVencimentoRecebimento'];

  constructor(private route: ActivatedRoute, private router: Router, private receitaDespesaService: ReceitadespesaService) { }

  ngOnInit() {
    this.despesaTotal = 0;
    this.receitaTotal = 0;

    this.receitaDespesaService.test().subscribe(data => {
      this.receitaDespesas = data;
      this.receitaDespesas.forEach(element => {
        if (element.tipo === 'Despesa') {
          this.despesaTotal += element.valor;
        } else {
          this.receitaTotal += element.valor;
        }
      });
    });
  }
}
