import { Injectable } from '@angular/core';
import { Feedback } from '../models/feedback';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  feedbackUrl: string;

  constructor() { }

  public delete(id: number) {
   this.feedbackUrl = 'http://localhost:8080/feedback';
  }

  public setFeedback(feedback: Feedback) {

  }

}
